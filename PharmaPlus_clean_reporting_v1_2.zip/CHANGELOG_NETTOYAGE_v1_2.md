# PharmaPlus - Nettoyage v1.2 proposé

## Nettoyage réalisé
- Suppression de la vérification token côté API pour les endpoints utilisateurs.
- Simplification de `routes/auth_api.py` : login uniquement, sans `/me`, sans `require_auth`, sans `require_role`.
- Suppression des headers `Authorization: Bearer ...` dans les appels JS.
- Suppression de `auth_guard.js` et `api_logger.js`.
- Suppression des références/commentaires inutiles à `auth_guard` et `api_logger`.
- Auto-refresh conservé uniquement sur le dashboard.
- Dashboard réglé à 10 secondes : `setInterval(refreshAll, 10_000)`.
- Suppression des dossiers `__pycache__` et `Server/logs` dans la version nettoyée.

## Ajout proposé
- Nouvelle page `templates/reporting.html`.
- Nouveau script `static/js/reporting.js`.
- Nouvelle API `Server/routes/reporting.py`.
- Enregistrement du blueprint dans `Server/app.py` :
  `app.register_blueprint(reporting_bp, url_prefix="/api/reporting")`.

## Rapports inclus
- Ventes par jour
- Ventes par mois
- Top produits
- Marge brute par mois
- Approvisionnements par fournisseur
- Mouvements de stock
- Déclassements / ajustements
- Lots à expiration
- Export CSV côté navigateur

## Fichiers principaux modifiés
- `Server/app.py`
- `Server/routes/auth_api.py`
- `Server/routes/users.py`
- `Server/routes/users_api.py`
- `Server/routes/reporting.py`
- `baseP/static/js/dashboard.js`
- `baseP/static/js/script.js`
- `baseP/static/js/users_admin.js`
- `baseP/static/js/nav.js`
- `baseP/static/js/login.js`
- `baseP/static/js/reporting.js`
- `baseP/templates/reporting.html`
- templates HTML avec ajout du lien Reporting
